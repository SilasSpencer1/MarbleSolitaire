

import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * to test functionality in the EuropeanSolitaireModel class.
 */
public final class EuropeanSolitaireModelTest {
  EuropeanSolitaireModel defaultCons1;
  EuropeanSolitaireModel e;

  EuropeanSolitaireModel defaultCons2;
  EuropeanSolitaireModel defaultCons3;
  EuropeanSolitaireModel defaultCons4;
  EuropeanSolitaireModel size_5;
  EuropeanSolitaireModel size_9;
  EuropeanSolitaireModel hole_0_2;
  EuropeanSolitaireModel size_5_hole_4_3;

  /**
   * Sets up objects to be tested.
   */
  @Before
  public void setUp() {
    defaultCons1 = new EuropeanSolitaireModel();
    defaultCons2 = new EuropeanSolitaireModel();
    defaultCons3 = new EuropeanSolitaireModel();
    defaultCons4 = new EuropeanSolitaireModel();
    size_5 = new EuropeanSolitaireModel(5);
    size_9 = new EuropeanSolitaireModel(9);
    hole_0_2 = new EuropeanSolitaireModel(0, 2);
    size_5_hole_4_3 = new EuropeanSolitaireModel(4, 3);
  }

  @Test
  public void testConstructorsAndtoString() {
    assertEquals("    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O", defaultCons1.toString());
    assertEquals("        O O O O O\n" +
            "      O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "      O O O O O O O\n" +
            "        O O O O O", size_5.toString());
    assertEquals("    _ O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O", hole_0_2.toString());
    assertEquals("                O O O O O O O O O\n" +
            "              O O O O O O O O O O O\n" +
            "            O O O O O O O O O O O O O\n" +
            "          O O O O O O O O O O O O O O O\n" +
            "        O O O O O O O O O O O O O O O O O\n" +
            "      O O O O O O O O O O O O O O O O O O O\n" +
            "    O O O O O O O O O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O _ O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O O O O O O O O O O O O O\n" +
            "    O O O O O O O O O O O O O O O O O O O O O\n" +
            "      O O O O O O O O O O O O O O O O O O O\n" +
            "        O O O O O O O O O O O O O O O O O\n" +
            "          O O O O O O O O O O O O O O O\n" +
            "            O O O O O O O O O O O O O\n" +
            "              O O O O O O O O O O O\n" +
            "                O O O O O O O O O", size_9.toString());
  }

  @Test
  public void move() {
    defaultCons1.move(3, 1, 3, 3);
    defaultCons2.move(3, 5, 3, 3);
    defaultCons3.move(1, 3, 3, 3);
    defaultCons4.move(5, 3, 3, 3);
    assertEquals("    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O", defaultCons1.toString());
    assertEquals("    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O _ _ O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O", defaultCons2.toString());
    assertEquals("    O O O\n" +
            "  O O _ O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O", defaultCons3.toString());
    assertEquals("    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "  O O _ O O\n" +
            "    O O O", defaultCons4.toString());
  }

  @Test
  public void badMoves() {
    int[][] moves = {
            {1, 1, 1, -1},
            {0, 2, 0, 4},
            {1, 5, 3, 3},
            {3, 3, 3, 5},
            {1, 2, 1, 0},
            {2, 2, 2, 4},
            {1, 3, -1, 3},
            {3, 5, 3, 7},
            {5, 3, 7, 3}
    };

    for (int i = 0; i < moves.length; i++) {
      try {
        defaultCons1.move(moves[i][0], moves[i][1], moves[i][2], moves[i][3]);
        fail(String.format("Failed on test %d", i + 1));
      } catch (IllegalArgumentException e) { /*Makes sure that move fails*/ }
    }
  }

  @Test
  public void isGameOver() {
    // assertEquals(false, hole_0_2.isGameOver());
    assertEquals(36, hole_0_2.getScore());
    hole_0_2.move(0, 4, 0, 2);
    assertEquals(35, hole_0_2.getScore());
    hole_0_2.move(2, 4, 0, 4);
    assertEquals(34, hole_0_2.getScore());
    hole_0_2.move(2, 3, 0, 3);
    hole_0_2.move(2, 1, 2, 3);
    hole_0_2.move(4, 2, 2, 2);
    hole_0_2.move(2, 2, 2, 4);
    hole_0_2.move(4, 1, 2, 1);
    hole_0_2.move(2, 0, 2, 2);
    hole_0_2.move(1, 2, 3, 2);
    hole_0_2.move(4, 0, 2, 0);
    hole_0_2.move(3, 3, 3, 1);
    hole_0_2.move(2, 5, 2, 3);
    hole_0_2.move(3, 5, 3, 3);
    hole_0_2.move(4, 4, 4, 2);
    hole_0_2.move(5, 2, 3, 2);
    hole_0_2.move(3, 2, 3, 4);
    hole_0_2.move(6, 3, 4, 3);
    hole_0_2.move(5, 5, 5, 3);
    hole_0_2.move(5, 3, 3, 3);
    hole_0_2.move(3, 3, 3, 5);
    assertEquals(false, hole_0_2.isGameOver());
    hole_0_2.move(3, 5, 5, 5);
    assertEquals(true, hole_0_2.isGameOver());
    assertEquals(15, hole_0_2.getScore());
    assertEquals("    O O O\n" +
            "  O _ _ _ O\n" +
            "O _ _ O _ _ O\n" +
            "_ O _ _ _ _ O\n" +
            "_ _ _ _ _ _ O\n" +
            "  O _ _ _ O\n" +
            "    O _ O", hole_0_2.toString());
  }

  @Test
  public void getScore() {
    assertEquals(36, defaultCons1.getScore());
    assertEquals(36, hole_0_2.getScore());
  }

  @Test(expected = IllegalArgumentException.class)
  public void tryNegSize() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(-3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void trySize4() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void trySize2() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void tryBadHole1() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void tryBadHole2() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(0, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void tryBadHole3() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(5, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void tryBadHole4() {
    EuropeanSolitaireModel bad_model = new EuropeanSolitaireModel(5, 0);
  }

  @Test
  public void testValidInitialConstructor() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", this.e.toString());

  }

  @Test
  public void testValidSecondConstructor() {
    this.e = new EuropeanSolitaireModel(3, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", this.e.toString());

  }

  @Test
  public void testValidThirdConstructor5() {
    this.e = new EuropeanSolitaireModel(5, 5, 5);
    assertEquals("        O O O O O\n"
            + "      O O O O O O O\n"
            + "    O O O O O O O O O\n"
            + "  O O O O O O O O O O O\n"
            + "O O O O O O O O O O O O O\n"
            + "O O O O O _ O O O O O O O\n"
            + "O O O O O O O O O O O O O\n"
            + "O O O O O O O O O O O O O\n"
            + "O O O O O O O O O O O O O\n"
            + "  O O O O O O O O O O O\n"
            + "    O O O O O O O O O\n"
            + "      O O O O O O O\n"
            + "        O O O O O", this.e.toString());
  }

  @Test
  public void testValidThirdConstructor3() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", this.e.toString());
  }

  @Test
  public void testValidThirdConstructorCustom() {
    this.e = new EuropeanSolitaireModel(3, 2, 6);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O _\n"
            + "O O O O O O O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", this.e.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidSecondConstructor() {
    this.e = new EuropeanSolitaireModel(-3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidThirdConstructorInvalidEmpty() {
    this.e = new EuropeanSolitaireModel(3, 3, -3);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidThirdConstructorBadArmLength() {
    this.e = new EuropeanSolitaireModel(4, 3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveNoFromMarble() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(3, 3, 0, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveTooFar() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(2, 3, 3, 6);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testDiagonalMove() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(2, 3, 4, 5);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveToMarbleGone() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(0, 3, 3, 3);
  }

  @Test
  public void testMoveLeft() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(3, 5, 3, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O O O O _ _ O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", e.toString());
  }

  @Test
  public void testMoveRight() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(3, 1, 3, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O _ _ O O O O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", e.toString());

  }

  @Test
  public void testMoveUp() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(5, 3, 3, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "  O O _ O O\n"
            + "    O O O", e.toString());
  }

  @Test
  public void testCenterOff() {
    this.e = new EuropeanSolitaireModel(3, 4, 3);
    assertEquals("    O O O\n"
            + "  O O O O O\n"
            + "O O O O O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "  O O O O O\n"
            + "    O O O", e.toString());

  }

  @Test
  public void testMoveDown() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    e.move(1, 3, 3, 3);
    assertEquals("    O O O\n"
            + "  O O _ O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "O O O O O O O\n"
            + "  O O O O O\n"
            + "    O O O", e.toString());
  }

  @Test
  public void testScore() {
    this.e = new EuropeanSolitaireModel(3, 3, 3);
    assertEquals(36, e.getScore());
    e.move(1, 3, 3, 3);
    assertEquals(35, e.getScore());

  }

  @Test
  public void testIsGameOverFalse() {

    this.e = new EuropeanSolitaireModel(3, 3, 3);
    assertEquals(false, e.isGameOver());
    e.move(1, 3, 3, 3);
    assertEquals(false, e.isGameOver());

  }
}
