package cs3500.marblesolitaire.controller.hw02;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import org.junit.Before;
import org.junit.Test;

import java.io.PipedWriter;
import java.io.StringReader;
import java.io.Writer;

import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;


import static org.junit.Assert.assertEquals;

/**
 * Test for controller.
 */
public class EnglishSolitaireControllerTest {
  StringBuilder ap1;
  StringBuilder ap2;
  StringBuilder ap3;
  StringBuilder ap4;
  StringBuilder ap5;
  StringBuilder ap6;
  StringBuilder ap7;
  StringBuilder ap8;
  StringBuilder null_ap;

  Writer closedAp;

  StringReader rd1;
  StringReader rd2;
  StringReader rd3;
  StringReader rd4;
  StringReader rd5;
  StringReader rd6;
  StringReader rd7;
  StringReader rd8;
  StringReader rd9;
  StringReader rd10;
  StringReader rd11;
  StringReader rd12;
  StringReader rd13;
  StringReader bad_rd1;
  StringReader bad_rd3;
  StringReader bad_rd4;
  StringReader bad_rd5;
  StringReader bad_rd6;
  StringReader bad_rd7;
  StringReader null_rd;

  MarbleSolitaireView view1;
  MarbleSolitaireView view2;

  MarbleSolitaireModelState ms1;

  EnglishSolitaireModel nullImpl;
  EnglishSolitaireModel emptyCons;
  EnglishSolitaireModel emptyCons2;
  EnglishSolitaireModel emptyCons3;
  EnglishSolitaireModel emptyCons4;


  MarbleSolitaireControllerImpl controller;
  MarbleSolitaireControllerImpl controller2;
  MarbleSolitaireControllerImpl controller3;
  MarbleSolitaireControllerImpl bad_ap_controller;
  MarbleSolitaireControllerImpl quit_controller4;
  MarbleSolitaireControllerImpl quit_controller1;
  MarbleSolitaireControllerImpl quit_controller2;
  MarbleSolitaireControllerImpl quit_controller3;
  MarbleSolitaireControllerImpl debugController;
  MarbleSolitaireControllerImpl test_move_controller;
  MarbleSolitaireControllerImpl test_move_controller2;
  MarbleSolitaireControllerImpl test_move_controller3;
  MarbleSolitaireControllerImpl test_move_controller4;
  MarbleSolitaireControllerImpl bad_controller1;
  MarbleSolitaireControllerImpl bad_controller2;
  MarbleSolitaireControllerImpl testBadRowAndColumn_controller;
  MarbleSolitaireControllerImpl testBadRowAndColumn_controller2;
  MarbleSolitaireControllerImpl testBadRowAndColumn_controller3;
  MarbleSolitaireControllerImpl testBadRowAndColumn_controller4;
  MarbleSolitaireControllerImpl testBadMovePromptUser_controller;
  MarbleSolitaireTextView view3;
  MarbleSolitaireTextView view4;
  MarbleSolitaireTextView view5;
  MarbleSolitaireTextView view6;
  MarbleSolitaireTextView view7;
  MarbleSolitaireTextView nullView;
  EnglishSolitaireModel emptyCons5;

  /**
   * Sets up data to be tested.
   */
  @Before
  public void setUp() {
    rd1 = new StringReader("4\n2\n4\n4\n q abc\n"); // Jumping from left onto middle square
    rd2 = new StringReader("2 2\n3 1\n Q");
    rd3 = new StringReader("q\n");
    rd4 = new StringReader("Q\n");
    rd5 = new StringReader("2 2\n3 1 q\n");
    rd6 = new StringReader("2 2\n3 1q\n");
    rd7 = new StringReader("Q");
    rd8 = new StringReader("4\n2\n4\n4\n4\n5\n4\n3 q \n");
    rd9 = new StringReader("2\n4\n4\n4\n q \n");
    rd10 = new StringReader("4\n2\n4\n4 adf \n-4 -6 4\n5 -3\n4\n3 q \n");
    rd11 = new StringReader("2 Q\n");
    rd12 = new StringReader("2 4 Q\n");
    rd13 = new StringReader("2 5 6 Q\n");
    bad_rd1 = new StringReader("abc Q");
    bad_rd3 = new StringReader("1 23 4 5\n q");
    bad_rd4 = new StringReader("-1 2 3 4 q");
    bad_rd5 = new StringReader("1 -2 3 4 q");
    bad_rd6 = new StringReader("1 2 -3 4 q");
    bad_rd7 = new StringReader("1 2 3 -4 q");

    ap1 = new StringBuilder();
    ap2 = new StringBuilder("   O O O\\n\" +\n"
            +
            "        \"    O O O\\n\" +\n"
            +
            "        \"O O O O O O O\\n\" +\n"
            +
            "        \"O O O _ O O O\\n\" +\n"
            +
            "        \"O O O O O O O\\n\" +\n"
            +
            "        \"    O O O\\n\" +\n"
            +
            "        \"    O O O"); // Standard initial board
    ap3 = new StringBuilder("   O O O\\n\" +\n"
            +
            "        \"    O O O\\n\" +\n"
            +
            "        \"O O O O O O O\\n\" +\n"
            +
            "        \"O _ _ O O O O\\n\" +\n"
            +
            "        \"O O O O O O O\\n\" +\n"
            +
            "        \"    O O O\\n\" +\n"
            +
            "        \"    O O O"); // Standard initial board, after jump specified by r1
    ap4 = new StringBuilder();
    ap5 = new StringBuilder();
    ap6 = new StringBuilder();
    ap7 = new StringBuilder();
    ap8 = new StringBuilder();
    closedAp = new PipedWriter();

    this.emptyCons = new EnglishSolitaireModel();
    this.emptyCons2 = new EnglishSolitaireModel();
    this.emptyCons3 = new EnglishSolitaireModel();
    this.emptyCons4 = new EnglishSolitaireModel();
    this.emptyCons5 = new EnglishSolitaireModel();
    this.ms1 = emptyCons;
    this.view1 = new MarbleSolitaireTextView(emptyCons, ap1);
    this.view2 = new MarbleSolitaireTextView(emptyCons, closedAp);
    this.view3 = new MarbleSolitaireTextView(emptyCons, ap7);
    this.view4 = new MarbleSolitaireTextView(emptyCons, ap8);
    this.view5 = new MarbleSolitaireTextView(emptyCons, ap4);
    this.view6 = new MarbleSolitaireTextView(emptyCons, ap5);
    this.view7 = new MarbleSolitaireTextView(emptyCons, ap6);

    this.nullView = new MarbleSolitaireTextView(emptyCons5, null_ap);

    this.bad_controller1 = new MarbleSolitaireControllerImpl(emptyCons, view1, bad_rd1);
    this.bad_ap_controller = new MarbleSolitaireControllerImpl(emptyCons, view2, bad_rd3);
    this.controller = new MarbleSolitaireControllerImpl(emptyCons, view1, rd7);
    this.controller2 = new MarbleSolitaireControllerImpl(emptyCons, view3, rd3);
    this.controller3 = new MarbleSolitaireControllerImpl(emptyCons, view4, rd4);

    this.quit_controller1 = new MarbleSolitaireControllerImpl(emptyCons, view1, rd7);
    this.quit_controller2 = new MarbleSolitaireControllerImpl(emptyCons, view5, rd11);
    this.quit_controller3 = new MarbleSolitaireControllerImpl(emptyCons, view6, rd12);
    this.quit_controller4 = new MarbleSolitaireControllerImpl(emptyCons, view3, rd13);

    this.test_move_controller = new MarbleSolitaireControllerImpl(emptyCons, view1, rd1);
    this.test_move_controller2 = new MarbleSolitaireControllerImpl(emptyCons, view7, rd8);
    this.test_move_controller3 = new MarbleSolitaireControllerImpl(emptyCons, view6, rd9);
    this.test_move_controller4 = new MarbleSolitaireControllerImpl(emptyCons, view5, rd10);

    this.testBadRowAndColumn_controller = new
            MarbleSolitaireControllerImpl(emptyCons, view1, bad_rd4);
    this.testBadRowAndColumn_controller2 = new
            MarbleSolitaireControllerImpl(emptyCons, view5, bad_rd5);
    this.testBadRowAndColumn_controller3 = new
            MarbleSolitaireControllerImpl(emptyCons, view6, bad_rd6);
    this.testBadRowAndColumn_controller4 = new
            MarbleSolitaireControllerImpl(emptyCons, view7, bad_rd7);
    this.testBadMovePromptUser_controller = new
            MarbleSolitaireControllerImpl(emptyCons, view1, rd2);
    this.bad_controller1 = new MarbleSolitaireControllerImpl(emptyCons, view1, bad_rd1);


  }

  @Test(expected = NullPointerException.class)
  public void testNullModel() {
    controller.playGame();
  }

  @Test(expected = IllegalStateException.class)
  public void testBadAppendable() {
    this.bad_ap_controller.playGame();
  }


  @Test
  public void testBadInput() {
    bad_controller1.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Please re-enter that move\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap1.toString());
  }


  @Test(expected = IllegalArgumentException.class)
  public void testNullrd() {
    bad_controller2 = new MarbleSolitaireControllerImpl(emptyCons, view1, null_rd);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testNullAppendable() {
    bad_controller2 = new MarbleSolitaireControllerImpl(emptyCons, nullView, rd1);
  }

  // Needed?
  @Test
  public void displayEmptyConsGameState() {
    controller.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap1.toString());
  }

  @Test
  public void testMove() {
    test_move_controller.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31", ap1.toString());
    test_move_controller2.playGame();
    // Tests consecutive moves
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ O _ _ O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 30\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ O _ _ O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 30", ap6.toString());
    test_move_controller3.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31", ap5.toString());
    test_move_controller4.playGame();
    // Tests that only invalid input is re-entered
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "Please re-enter that move\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "Please re-enter that move\n" +
            "Please re-enter that move\n" +
            "Please re-enter that move\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ O _ _ O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 30\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ O _ _ O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 30", ap4.toString());
  }

  @Test
  public void testBadRowOrColumn() {
    testBadRowAndColumn_controller.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Please re-enter that move\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap1.toString());
    testBadRowAndColumn_controller2.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Please re-enter that move\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap4.toString());
    testBadRowAndColumn_controller3.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Please re-enter that move\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap5.toString());
    testBadRowAndColumn_controller4.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Please re-enter that move\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap6.toString());
  }

  @Test
  public void badMovePromptUser() {
    testBadMovePromptUser_controller.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Invalid move. Play again. Invalid move:\n" +
            "From row 2, column 2\n" +
            "To row 3, column 1.\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap1.toString());
  }

  @Test
  public void testQuits() {
    this.quit_controller1.playGame();
    this.quit_controller2.playGame();
    this.quit_controller3.playGame();
    this.quit_controller4.playGame();
    this.controller2.playGame();
    this.controller3.playGame();
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap1.toString());
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap4.toString());
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap5.toString());
    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32", ap6.toString());
    assertEquals("    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O\n" +
            "Score: 14\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O\n" +
            "Score: 14", ap7.toString());
    assertEquals("    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O\n" +
            "Score: 36\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O\n" +
            "Score: 36", ap8.toString());
  }
}
